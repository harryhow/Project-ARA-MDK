/*
 * Copyright (C) 2014 Google, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.motorola.arathermal;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.hardware.I2cManager;
import android.hardware.I2cTransaction;
import android.widget.TextView;
import java.io.IOException;
import android.os.Handler;

public class MainActivity extends Activity implements Mlx90620Listener{

    TextView textView;
    TemperaturePanel temperaturePanel;
    Mlx90620Thread thread;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView)findViewById(R.id.textView);
        temperaturePanel = (TemperaturePanel)findViewById(R.id.temperaturePanel);
        handler = new Handler();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    protected void onStart(){
        super.onStart();
        I2cManager i2c = (I2cManager) getSystemService(I2C_SERVICE);
        thread = new Mlx90620Thread(this, i2c);
        thread.start();
    }

    @Override
    protected void onStop() {
    	super.onStop();
    	thread.requestStop();
    }

    // -- Mlx90620 API --------------------------------------------------------

    @Override
    public void updateMlx90620Status(String text) {
        final String t = text;
        handler.post(new Runnable() {
                @Override
                public void run() {
                    textView.setText(t);
                }
            });
    }

    @Override
    public void updateMlx90620Temps(float[][] temps) {
        // Just delegate to TemperaturePanel
        temperaturePanel.updateTemperatures(temps);
    }

}
