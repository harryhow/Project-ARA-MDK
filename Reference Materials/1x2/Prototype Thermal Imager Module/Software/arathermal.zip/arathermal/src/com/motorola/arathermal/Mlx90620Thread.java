/*
 * Copyright (C) 2014 Google, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.motorola.arathermal;

import android.hardware.I2cManager;
import android.hardware.I2cTransaction;
import android.util.Log;
import java.io.IOException;

public class Mlx90620Thread extends Thread {

    int freq = 16;  //Set this value to your desired refresh frequency
    int[] irData = new int[64];
    byte CFG_LSB, CFG_MSB, PTAT_LSB, PTAT_MSB, CPIX_LSB, CPIX_MSB, PIX_LSB, PIX_MSB;
    int PIX, v_th, CPIX;
    float ta, to, emissivity, k_t1, k_t2;
    float[] temperatures = new float[64];
    float[] v_ir_tgc_comp =  new float[64];
    //--> this is a random test value
    double[] alphaDbl_ij = new double[] {1.591E-8, 1.736E-8, 1.736E-8, 1.620E-8, 1.783E-8, 1.818E-8, 1.992E-8, 1.748E-8, 1.864E-8, 2.056E-8, 2.132E-8, 2.033E-8, 2.097E-8, 2.324E-8, 2.388E-8, 2.161E-8, 2.155E-8, 2.394E-8, 2.353E-8, 2.068E-8, 2.353E-8, 2.633E-8, 2.708E-8, 2.394E-8, 2.499E-8, 2.778E-8, 2.731E-8, 2.580E-8, 2.539E-8, 2.796E-8, 2.871E-8, 2.598E-8, 2.586E-8, 2.801E-8, 2.830E-8, 2.633E-8, 2.609E-8, 2.894E-8, 2.924E-8, 2.633E-8, 2.464E-8, 2.778E-8, 2.894E-8, 2.673E-8, 2.475E-8, 2.737E-8, 2.796E-8, 2.679E-8, 2.394E-8, 2.708E-8, 2.714E-8, 2.644E-8, 2.347E-8, 2.563E-8, 2.493E-8, 2.388E-8, 2.179E-8, 2.440E-8, 2.504E-8, 2.295E-8, 2.033E-8, 2.283E-8, 2.295E-8, 2.155E-8};
    float[] alpha_ij = new float[64];

    int count;
    int PTAT;
    int a_cp, b_cp, tgc, b_i_scale;
    int[] a_ij = new int[64];
    int[] b_ij = new int[64];
    byte[] eepromDataRaw, irDataRaw, cpixDataRaw;
    int[] eepromDataInt, irDataInt, cpixDataInt;
    int tmp;    // temporary placeholder

    private static final String TAG = "Mlx90620Thread";

    Mlx90620Listener listener;
    I2cManager i2c;
    boolean stopped;
    String bus;

    private static final int imagerAddress = 0x60; // 7-bit address; 8-bit "write" version is 0xC0
    private static final int eepromAddress = 0x50; // 7-bit address; 8-bit "write" version is 0xA0

    public Mlx90620Thread(Mlx90620Listener listener, I2cManager i2c){
        this.listener = listener;
        this.i2c = i2c;
        PTAT = 0;
        stopped = false;
        temperatures = new float[64];
        a_ij = new int[64];
        b_ij = new int[64];
        for (int i=0;i<64;i++) {
            alpha_ij[i] = (float)alphaDbl_ij[i];
        }
    }

    public void requestStop() {
        synchronized (this) {
            this.stopped = true;
        }
    }

    public boolean isStopped() {
        synchronized (this) {
            return this.stopped;
        }
    }

    @Override
    public void run(){

        count = 0;

        String[] buses = i2c.getI2cBuses();
        if (buses.length==0){
            listener.updateMlx90620Status("No buses");
            return;
        }

        bus = buses[0];

        // ==============
        // void setup()
        // ==============
        read_EEPROM_MLX90620();
        config_MLX90620_Hz(16); // 16 is the "refresh frequency" (aka frame rate)

        // ==============
        // void loop()
        // ==============
        float[][] normalizedTemps = new float[4][16];
        float minTemp = 25;     // minimum temperature we expect to see
        float maxTemp = 50;     // maximum temperature we expect to see
        float tempSpread = maxTemp - minTemp;
        while (!isStopped()){

            if (count==0) {
                read_PTAT_Reg_MLX90620();
                calculate_TA();
                check_Config_Reg_MLX90620();
            }
            count++;
            if (count >= freq) {
                count = 0;
            }
            try {Thread.sleep(100);} catch (InterruptedException e) {}
            read_IR_ALL_MLX90620();
            read_CPIX_Reg_MLX90620();
            calculate_TO();

            // Convert column-major temperatures to row-major
            // normalized temperatures.
            int t = 0;
            for (int c = 0; c < 16; c++) {
                for (int r = 0; r < 4; r++) {
                    float normTemp = (temperatures[t] - minTemp) / tempSpread;
                    // Clamp normalized temperature to lie within [0.0f, 1.0f].
                    if (normTemp > 1.0f) {
                        normTemp = 1.0f;
                    } else if (normTemp < 0.0f) {
                        normTemp = 0.0f;
                    }
                    normalizedTemps[r][c] = normTemp;
                    t++;
                }
            }
            listener.updateMlx90620Temps(normalizedTemps);
            //Temperatures_Serial_Transmit();

        }
    }

    private void read_EEPROM_MLX90620() {
        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x00});
        I2cTransaction readTxns = I2cTransaction.newRead(256);
        Log.i(TAG, "before doing txns, write status = " + writeTxn.status + ", read status = " +
                    readTxns.status);
        I2cTransaction[] results;
        try {
            results = i2c.performTransactions(bus, eepromAddress, new I2cTransaction[] {writeTxn, readTxns});
        } catch (IOException e) {
            Log.e(TAG, "Can't read EEPROM");
            listener.updateMlx90620Status("Can't read EEPROM");
            throw new RuntimeException();
        }

        eepromDataRaw = results[1].data;
        eepromDataInt = b2iVec(eepromDataRaw);

        /*String s = "";

        for (byte b: this.eepromDataRaw) {
            s += String.format("%x, ", b); //
        }

        listener.updateMlx90620Status(s);*/

        varInitialization();
        write_trimming_value();
    }

    private void varInitialization(){
        v_th = (eepromDataInt[219] << 8) + eepromDataInt[218];
        k_t1 = ((eepromDataInt[221] << 8) + eepromDataInt[220])/1024f;
        k_t2 = ((eepromDataInt[223] << 8) + eepromDataInt[222])/1048576f;

        // Use the raw data, and skip the if block
        a_cp = eepromDataRaw[212];
        b_cp = eepromDataRaw[213];
        tgc = eepromDataRaw[216];

        b_i_scale = eepromDataInt[217];

        emissivity = ((eepromDataInt[229] << 8) + eepromDataInt[228])/32768f;

        for(int i=0;i<=63;i++){
            // Use the raw data, and skip the if block
            a_ij[i] = eepromDataRaw[i];
            b_ij[i] = eepromDataRaw[64+i];
        }

    }

    private void write_trimming_value(){
        byte val = eepromDataRaw[247];
        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x04, (byte)(b2i(val)-0xAA), val, 0x56, 0x00});
        // this should be equivalent to in the arduino code ----------------------------^
        try {
            I2cTransaction[] results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn});
        } catch (IOException e) {
            Log.e(TAG, "Can't write to imager");
            listener.updateMlx90620Status("Can't write to imager");
            throw new RuntimeException();
        }
    }

    private void config_MLX90620_Hz(int Hz){
        // this should be fine since none of the literals are >127
        // but even if they were, wouldn't the bits be preserved in the casting?
        byte Hz_LSB;
        switch (Hz) {
            case 0:
            //Hz_LSB = 0b00001111;
            Hz_LSB = 0xf;
            break;
            case 1:
            //Hz_LSB = 0b00001110;
            Hz_LSB = 0xe;
            break;
            case 2:
            //Hz_LSB = 0b00001101;
            Hz_LSB = 0xd;
            break;
            case 4:
            //Hz_LSB = 0b00001100;
            Hz_LSB = 0xc;
            break;
            case 8:
            //Hz_LSB = 0b00001011;
            Hz_LSB = 0xb;
            break;
            case 16:
            //Hz_LSB = 0b00001010;
            Hz_LSB = 0xa;
            break;
            case 32:
            //Hz_LSB = 0b00001001;
            Hz_LSB = 0x9;
            break;
            default:
            //Hz_LSB = 0b00001110;
            Hz_LSB = 0xe;
        }
        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x03, (byte)(b2i(Hz_LSB)-0x55), Hz_LSB, 0x1F, 0x74});
        // same as in write_trimming_value
        try {
            I2cTransaction[] results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn});
        } catch (IOException e) {
            Log.e(TAG, "Can't write to imager");
            listener.updateMlx90620Status("Can't write to imager");
            throw new RuntimeException();
        }
    }

    private int b2i(byte b) {
        // converts a byte (which is signed in java) into an int
        //  with the value it would have if the byte were unsigned
        if (b < 0) {    // this means that the original value was >127, so it wrapped around
            return (int)b + 256;
        } else {
            return (int)b;
        }

    }

    private int[] b2iVec(byte[] input) {
        int[] output = new int[input.length];
        for (int i=0; i<input.length; i++) {
            output[i] = b2i(input[i]);
        }
        return output;
    }

    private void read_PTAT_Reg_MLX90620(){

        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x02, (byte)0x90, 0x00, 0x01});
        // should i explicitly cast all of these bytes? what about expressions? why do i even need to do that?
        I2cTransaction readTxns = I2cTransaction.newRead(2);
        I2cTransaction[] results;

        try {
            results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn, readTxns});
        } catch (IOException e) {
            Log.e(TAG, "Can't read imager");
            listener.updateMlx90620Status("Can't read imager");
            throw new RuntimeException();
        }

        PTAT = (b2i(results[1].data[1]) << 8) + b2i(results[1].data[0]);
    }


    private void calculate_TA(){ 
        ta = (float)((-k_t1 + Math.sqrt(k_t1*k_t1 - (4 * k_t2 * (v_th - (float)PTAT))))/(2*k_t2) + 25); 	
    }


    private void check_Config_Reg_MLX90620(){
        read_Config_Reg_MLX90620();
        /*if ((!CFG_MSB & 0x04) == 0x04){ //  this will never happen
            config_MLX90620_Hz(freq);
        }*/
    }


    private void read_Config_Reg_MLX90620(){

        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x02, (byte)0x92, 0x00, 0x01});
        I2cTransaction readTxns = I2cTransaction.newRead(2);
        I2cTransaction[] results;

        try {
            results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn, readTxns});
        } catch (IOException e) {
            Log.e(TAG, "Can't read imager");
            listener.updateMlx90620Status("Can't read imager");
            throw new RuntimeException();
        }

        CFG_LSB = results[1].data[0];
        CFG_MSB = results[1].data[1];

    }

    private void read_IR_ALL_MLX90620(){

        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x02, 0x00, 0x01, 0x40});
        I2cTransaction readTxns = I2cTransaction.newRead(128);
        I2cTransaction[] results;
        try {
            results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn, readTxns});
        } catch (IOException e) {
            Log.e(TAG, "Can't read imager");
            listener.updateMlx90620Status("Can't read imager");
            throw new RuntimeException();
        }
        irDataRaw = results[1].data;
        irDataInt = b2iVec(irDataRaw);
        for (int i=0; i<64; i++) {
            tmp = (irDataInt[2*i+1] << 8) + irDataInt[2*i];
            if (tmp > 32767) {
                irData[i] = tmp - 65536;
            } else {
                irData[i] = tmp;
            }
        }

    }

    private void read_CPIX_Reg_MLX90620(){

        I2cTransaction writeTxn = I2cTransaction.newWrite(new byte[] {0x02, (byte)0x91, 0x00, 0x01});
        I2cTransaction readTxns = I2cTransaction.newRead(2);
        I2cTransaction[] results;
        try {
            results = i2c.performTransactions(bus, imagerAddress, new I2cTransaction[] {writeTxn, readTxns});
        } catch (IOException e) {
            Log.e(TAG, "Can't read imager");
            listener.updateMlx90620Status("Can't read imager");
            throw new RuntimeException();
        }
        cpixDataRaw = results[1].data;
        cpixDataInt = b2iVec(cpixDataRaw);
        CPIX = (cpixDataInt[1] << 8) + cpixDataInt[0];

    }

    void calculate_TO(){

        float v_cp_off_comp = (float)CPIX - (float)(a_cp + (b_cp/Math.pow(2, b_i_scale)) * (ta - 25f)); 

        for (int i=0; i<64; i++){
            v_ir_tgc_comp[i] = irData[i] - (a_ij[i] + (float)(b_ij[i]/Math.pow(2, b_i_scale)) * (ta - 25)) - (((float)tgc/32)*v_cp_off_comp);
            temperatures[i] = (float)Math.sqrt(Math.sqrt((v_ir_tgc_comp[i]/alpha_ij[i]) + Math.pow((ta + 273.15),4))) - 273.15f;	
            // for now just get rid of alpha so that it compiles...
            //this.temperatures[i] = (float)Math.sqrt(Math.sqrt((v_ir_tgc_comp[i]) + Math.pow((ta + 273.15),4))) - 273.15f;	
        }

    }

}


